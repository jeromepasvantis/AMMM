config = {'numIndividuals':100 , 'maxNumGen':20, 'eliteProp':0.1, 'mutantProp':0.8,  'inheritanceProb':0.1}
