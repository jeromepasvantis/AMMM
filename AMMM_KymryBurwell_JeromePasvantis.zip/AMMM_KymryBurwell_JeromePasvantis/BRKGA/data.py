
# Set 1
nNurses = 20
hours =  24
demand = [ 2,2,1,1,1,2,2,3,4,6,6,7,5,8,8,7,6,6,4,3,4,3,3,3 ]
minHours = 5
maxHours = 9
maxConsec = 3
maxPresence = 14
'''
# Set 2
nNurses = 60
hours =  24
demand = [ 4,5,9,9,9,6,12,12,13,13,16,16,17,19,12,12,14,10,10,8,8,6,6,6 ]
minHours = 4
maxHours = 10
maxConsec = 4
maxPresence = 12

# Set 3
nNurses = 120
hours =  24
demand = [ 15,20,20,20,22,25,35,40,40,40,40,45,45,40,35,35,28,26,22,22,18,18,18,15 ]
minHours = 4
maxHours = 10
maxConsec = 5
maxPresence = 12

# Set 4
nNurses = 220
hours =  24
demand = [ 24,28,28,28,28,29,41,48,49,53,54,59,60,58,55,55,54,49,49,48,40,35,30,28 ]
minHours = 4
maxHours = 10
maxConsec = 5
maxPresence = 12

# Set 5
nNurses = 100
hours =  24
demand = [ 18,19,17,18,20,21,23,24,24,28,32,32,33,30,29,28,27,26,25,20,18,18,18,19 ]
minHours = 4
maxHours = 10
maxConsec = 5
maxPresence = 13

# Set 6
nNurses = 400
hours =  24
demand = [ 75,75,80,80,82,83,84,90,90,91,91,92,92,94,93,93,92,84,80,70,70,65,65,60 ]
minHours = 4
maxHours = 10
maxConsec = 5
maxPresence = 13
'''
